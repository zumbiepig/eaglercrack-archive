
# Eagler Context Redacted Diff
# Copyright (c) 2023 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  2 : 4  @  2 : 7

~ import net.lax1dude.eaglercraft.v1_8.EaglercraftRandom;
~ 

> DELETE  4  @  4 : 5

> CHANGE  8 : 9  @  8 : 9

~ 	public void updateTick(World world, BlockPos blockpos, IBlockState var3, EaglercraftRandom random) {

> DELETE  52  @  52 : 69

> CHANGE  4 : 5  @  4 : 5

~ 	public boolean canUseBonemeal(World var1, EaglercraftRandom random, BlockPos var3, IBlockState var4) {

> DELETE  2  @  2 : 6

> EOF
