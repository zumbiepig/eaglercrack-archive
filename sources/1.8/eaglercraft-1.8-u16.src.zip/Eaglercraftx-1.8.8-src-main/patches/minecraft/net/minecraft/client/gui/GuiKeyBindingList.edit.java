
# Eagler Context Redacted Diff
# Copyright (c) 2023 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> INSERT  3 : 5  @  3

+ 
+ import net.lax1dude.eaglercraft.v1_8.ArrayUtils;

> DELETE  1  @  1 : 4

> DELETE  4  @  4 : 5

> EOF
