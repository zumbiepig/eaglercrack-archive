
# Eagler Context Redacted Diff
# Copyright (c) 2023 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  3 : 5  @  3 : 6

~ import net.lax1dude.eaglercraft.v1_8.EaglercraftRandom;
~ 

> CHANGE  43 : 44  @  43 : 44

~ 	public int quantityDropped(EaglercraftRandom var1) {

> DELETE  16  @  16 : 19

> DELETE  4  @  4 : 7

> EOF
