
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> DELETE  2  @  2 : 3

> INSERT  4 : 10  @  4

+ 
+ import com.google.common.collect.Lists;
+ 
+ import net.lax1dude.eaglercraft.v1_8.Mouse;
+ import net.lax1dude.eaglercraft.v1_8.opengl.GlStateManager;
+ import net.lax1dude.eaglercraft.v1_8.opengl.WorldRenderer;

> DELETE  6  @  6 : 7

> DELETE  2  @  2 : 3

> DELETE  11  @  11 : 12

> CHANGE  71 : 72  @  71 : 72

~ 	protected void actionPerformed(GuiButton parGuiButton) {

> CHANGE  270 : 272  @  270 : 271

~ 			for (int m = 0, l = StatList.objectMineStats.size(); m < l; ++m) {
~ 				StatCrafting statcrafting = StatList.objectMineStats.get(m);

> CHANGE  133 : 135  @  133 : 134

~ 			for (int m = 0, l = StatList.itemStats.size(); m < l; ++m) {
~ 				StatCrafting statcrafting = StatList.itemStats.get(m);

> EOF
