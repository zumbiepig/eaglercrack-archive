
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> INSERT  2 : 4  @  2

+ import java.util.Collection;
+ 

> CHANGE  4 : 5  @  4 : 6

~ 

> CHANGE  12 : 13  @  12 : 13

~ 		return create(name, Collections2.filter(Lists.newArrayList(EnumFacing._VALUES), filter));

> EOF
