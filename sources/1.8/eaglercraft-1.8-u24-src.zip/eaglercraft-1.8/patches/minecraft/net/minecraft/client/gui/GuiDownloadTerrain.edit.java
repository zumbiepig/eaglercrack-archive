
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> DELETE  2  @  2 : 4

> CHANGE  12 : 13  @  12 : 13

~ 	protected void keyTyped(char parChar1, int parInt1) {

> INSERT  24 : 28  @  24

+ 
+ 	public boolean shouldHangupIntegratedServer() {
+ 		return false;
+ 	}

> EOF
