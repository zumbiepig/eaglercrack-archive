
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  3 : 4  @  3 : 5

~ 

> CHANGE  31 : 32  @  31 : 32

~ 		for (int i = 0; i < EnumDyeColor.META_LOOKUP.length; ++i) {

> DELETE  29  @  29 : 30

> DELETE  6  @  6 : 7

> EOF
