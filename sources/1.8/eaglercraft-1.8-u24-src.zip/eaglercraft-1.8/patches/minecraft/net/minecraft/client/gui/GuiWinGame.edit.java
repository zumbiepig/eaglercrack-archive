
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> DELETE  2  @  2 : 3

> DELETE  1  @  1 : 2

> CHANGE  3 : 13  @  3 : 4

~ import net.lax1dude.eaglercraft.v1_8.EaglercraftRandom;
~ 
~ import com.google.common.base.Charsets;
~ import com.google.common.collect.Lists;
~ 
~ import net.lax1dude.eaglercraft.v1_8.log4j.LogManager;
~ import net.lax1dude.eaglercraft.v1_8.log4j.Logger;
~ import net.lax1dude.eaglercraft.v1_8.opengl.GlStateManager;
~ import net.lax1dude.eaglercraft.v1_8.opengl.WorldRenderer;
~ import net.lax1dude.eaglercraft.v1_8.profile.EaglerProfile;

> DELETE  2  @  2 : 5

> DELETE  1  @  1 : 2

> DELETE  4  @  4 : 7

> CHANGE  28 : 29  @  28 : 29

~ 	protected void keyTyped(char parChar1, int parInt1) {

> CHANGE  28 : 29  @  28 : 29

~ 				EaglercraftRandom random = new EaglercraftRandom(8124371L);

> CHANGE  4 : 5  @  4 : 5

~ 					for (s = s.replaceAll("PLAYERNAME", EaglerProfile.getName()); s

> CHANGE  22 : 23  @  22 : 23

~ 					s = s.replaceAll("PLAYERNAME", EaglerProfile.getName());

> EOF
