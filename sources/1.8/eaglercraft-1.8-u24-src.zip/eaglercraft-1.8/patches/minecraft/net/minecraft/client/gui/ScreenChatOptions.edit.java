
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> DELETE  2  @  2 : 7

> CHANGE  22 : 24  @  22 : 23

~ 		for (int j = 0; j < field_146399_a.length; ++j) {
~ 			GameSettings.Options gamesettings$options = field_146399_a[j];

> CHANGE  16 : 17  @  16 : 17

~ 	protected void actionPerformed(GuiButton parGuiButton) {

> EOF
