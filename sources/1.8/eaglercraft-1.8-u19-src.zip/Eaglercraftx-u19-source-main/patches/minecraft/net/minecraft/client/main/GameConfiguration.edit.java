
# Eagler Context Redacted Diff
# Copyright (c) 2023 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> DELETE  2  @  2 : 5

> DELETE  5  @  5 : 6

> DELETE  1  @  1 : 2

> CHANGE  2 : 3  @  2 : 4

~ 			GameConfiguration.DisplayInformation displayInfoIn, GameConfiguration.GameInformation gameInfoIn) {

> DELETE  2  @  2 : 3

> DELETE  1  @  1 : 2

> DELETE  16  @  16 : 30

> DELETE  10  @  10 : 20

> DELETE  2  @  2 : 5

> CHANGE  1 : 2  @  1 : 3

~ 		public UserInformation(Session parSession) {

> DELETE  1  @  1 : 4

> EOF
