
# Eagler Context Redacted Diff
# Copyright (c) 2023 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  2 : 4  @  2 : 7

~ import net.lax1dude.eaglercraft.v1_8.EaglercraftRandom;
~ 

> DELETE  18  @  18 : 19

> DELETE  2  @  2 : 3

> CHANGE  10 : 11  @  10 : 11

~ 	protected EaglercraftRandom rand = new EaglercraftRandom();

> DELETE  12  @  12 : 41

> CHANGE  2 : 3  @  2 : 17

~ 		return true;

> DELETE  37  @  37 : 44

> EOF
