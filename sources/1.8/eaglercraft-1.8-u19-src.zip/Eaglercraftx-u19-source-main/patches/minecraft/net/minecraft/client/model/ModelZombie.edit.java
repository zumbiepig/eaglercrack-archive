
# Eagler Context Redacted Diff
# Copyright (c) 2023 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> DELETE  2  @  2 : 3

> CHANGE  5 : 6  @  5 : 6

~ 		this(0.0F, true);

> CHANGE  7 : 8  @  7 : 8

~ 		super(modelSize, 0.0F, 64, parFlag ? 64 : 32);

> EOF
