
# Eagler Context Redacted Diff
# Copyright (c) 2023 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  2 : 3  @  2 : 9

~ import net.lax1dude.eaglercraft.v1_8.Mouse;

> DELETE  4  @  4 : 5

> DELETE  2  @  2 : 4

> DELETE  2  @  2 : 3

> CHANGE  20 : 21  @  20 : 21

~ 		guibutton.enabled = false;

> CHANGE  2 : 3  @  2 : 3

~ 	protected void actionPerformed(GuiButton parGuiButton) {

> DELETE  6  @  6 : 7

> DELETE  5  @  5 : 8

> CHANGE  18 : 19  @  18 : 19

~ 			break;

> CHANGE  6 : 9  @  6 : 7

~ 		if (Mouse.isActuallyGrabbed()) {
~ 			Mouse.setGrabbed(false);
~ 		}

> EOF
