
# Eagler Context Redacted Diff
# Copyright (c) 2023 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  2 : 4  @  2 : 5

~ import net.lax1dude.eaglercraft.v1_8.EaglercraftRandom;
~ 

> DELETE  4  @  4 : 5

> CHANGE  73 : 74  @  73 : 74

~ 	public void randomTick(World worldIn, BlockPos pos, IBlockState state, EaglercraftRandom random) {

> CHANGE  2 : 3  @  2 : 8

~ 	public void updateTick(World worldIn, BlockPos pos, IBlockState state, EaglercraftRandom rand) {

> DELETE  1  @  1 : 2

> DELETE  2  @  2 : 12

> EOF
