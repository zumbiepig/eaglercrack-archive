
# Eagler Context Redacted Diff
# Copyright (c) 2023 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> DELETE  2  @  2 : 3

> INSERT  1 : 4  @  1

+ 
+ import com.google.common.collect.Lists;
+ 

> DELETE  1  @  1 : 6

> DELETE  1  @  1 : 2

> DELETE  4  @  4 : 6

> CHANGE  9 : 10  @  9 : 20

~ 		return (GuiListExtended.IGuiListEntry) this.field_148198_l.get(i);

> CHANGE  3 : 4  @  3 : 4

~ 		return this.field_148198_l.size();

> DELETE  23  @  23 : 32

> EOF
