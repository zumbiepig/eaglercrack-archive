
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  2 : 3  @  2 : 4

~ import net.lax1dude.eaglercraft.v1_8.mojang.authlib.GameProfile;

> DELETE  2  @  2 : 6

> DELETE  6  @  6 : 7

> DELETE  44  @  44 : 62

> EOF
