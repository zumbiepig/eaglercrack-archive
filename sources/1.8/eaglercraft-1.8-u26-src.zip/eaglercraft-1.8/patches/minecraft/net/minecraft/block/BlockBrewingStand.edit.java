
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  3 : 5  @  3 : 5

~ import net.lax1dude.eaglercraft.v1_8.EaglercraftRandom;
~ 

> CHANGE  69 : 70  @  69 : 72

~ 		if (!world.isRemote) {

> DELETE  5  @  5 : 7

> INSERT  1 : 2  @  1

+ 		return true;

> CHANGE  13 : 14  @  13 : 14

~ 	public void randomDisplayTick(World world, BlockPos blockpos, IBlockState var3, EaglercraftRandom random) {

> CHANGE  15 : 16  @  15 : 16

~ 	public Item getItemDropped(IBlockState var1, EaglercraftRandom var2, int var3) {

> EOF
