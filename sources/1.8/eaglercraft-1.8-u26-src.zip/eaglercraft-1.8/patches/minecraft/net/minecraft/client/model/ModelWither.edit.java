
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> DELETE  2  @  2 : 4

> CHANGE  39 : 41  @  39 : 41

~ 		for (int i = 0; i < this.field_82904_b.length; ++i) {
~ 			this.field_82904_b[i].render(f5);

> CHANGE  2 : 4  @  2 : 4

~ 		for (int i = 0; i < this.field_82905_a.length; ++i) {
~ 			this.field_82905_a[i].render(f5);

> EOF
