
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  3 : 5  @  3 : 6

~ import net.lax1dude.eaglercraft.v1_8.EaglercraftRandom;
~ 

> CHANGE  29 : 32  @  29 : 31

~ 		EnumDyeColor[] colors = EnumDyeColor.META_LOOKUP;
~ 		for (int i = 0; i < colors.length; ++i) {
~ 			list.add(new ItemStack(item, 1, colors[i].getMetadata()));

> CHANGE  12 : 13  @  12 : 13

~ 	public int quantityDropped(EaglercraftRandom var1) {

> DELETE  19  @  19 : 20

> DELETE  6  @  6 : 7

> EOF
