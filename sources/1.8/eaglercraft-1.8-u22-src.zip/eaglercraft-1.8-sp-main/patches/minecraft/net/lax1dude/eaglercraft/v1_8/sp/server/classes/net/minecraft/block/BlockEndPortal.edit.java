
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  3 : 4  @  3 : 4

~ import net.lax1dude.eaglercraft.v1_8.EaglercraftRandom;

> CHANGE  53 : 54  @  53 : 54

~ 	public int quantityDropped(EaglercraftRandom var1) {

> CHANGE  4 : 5  @  4 : 5

~ 		if (entity.ridingEntity == null && entity.riddenByEntity == null) {

> CHANGE  5 : 6  @  5 : 6

~ 	public void randomDisplayTick(World world, BlockPos blockpos, IBlockState var3, EaglercraftRandom random) {

> EOF
