
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  14 : 17  @  14 : 17

~ import net.minecraft.nbt.JsonToNBT;
~ import net.minecraft.nbt.NBTException;
~ import net.minecraft.nbt.NBTTagCompound;

> CHANGE  141 : 142  @  141 : 142

~ 				for (BlockPos blockpos5 : (ArrayList<BlockPos>) arraylist) {

> EOF
