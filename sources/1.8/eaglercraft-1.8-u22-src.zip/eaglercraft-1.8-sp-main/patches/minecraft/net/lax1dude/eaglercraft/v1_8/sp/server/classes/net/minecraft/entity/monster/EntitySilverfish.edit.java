
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  2 : 3  @  2 : 3

~ import net.lax1dude.eaglercraft.v1_8.EaglercraftRandom;

> CHANGE  137 : 138  @  137 : 138

~ 				EaglercraftRandom random = this.field_179485_a.getRNG();

> CHANGE  62 : 63  @  62 : 63

~ 				EaglercraftRandom random = this.silverfish.getRNG();

> EOF
