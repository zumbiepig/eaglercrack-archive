
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> DELETE  7  @  7 : 8

> DELETE  5  @  5 : 7

> CHANGE  21 : 22  @  21 : 22

~ 		if (!(aisle == null || aisle.length <= 0) && !StringUtils.isEmpty(aisle[0])) {

> CHANGE  18 : 19  @  18 : 19

~ 							this.symbolMap.put(Character.valueOf(c0), null);

> CHANGE  27 : 28  @  27 : 29

~ 		Predicate[][][] apredicate = new Predicate[this.depth.size()][this.aisleHeight][this.rowWidth];

> EOF
