
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  2 : 3  @  2 : 3

~ import net.lax1dude.eaglercraft.v1_8.EaglercraftRandom;

> CHANGE  51 : 52  @  51 : 52

~ 	public void updateTick(World world, BlockPos blockpos, IBlockState iblockstate, EaglercraftRandom var4) {

> CHANGE  15 : 16  @  15 : 16

~ 			if (world.rand.nextFloat() < f - 0.5F) {

> CHANGE  50 : 51  @  50 : 51

~ 	public Item getItemDropped(IBlockState var1, EaglercraftRandom random, int i) {

> EOF
