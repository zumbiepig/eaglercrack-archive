
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  6 : 7  @  6 : 7

~ import net.lax1dude.eaglercraft.v1_8.EaglercraftRandom;

> CHANGE  1 : 2  @  1 : 2

~ import net.lax1dude.eaglercraft.v1_8.EaglercraftUUID;

> CHANGE  24 : 25  @  24 : 25

~ import net.minecraft.nbt.NBTTagCompound;

> CHANGE  17 : 19  @  17 : 18

~ 	private static final EaglercraftUUID attackingSpeedBoostModifierUUID = EaglercraftUUID
~ 			.fromString("020E0DFB-87AE-4653-9556-831010E291A0");

> DELETE  83  @  83 : 94

> CHANGE  143 : 144  @  143 : 146

~ 				this.setScreaming(true);

> CHANGE  40 : 41  @  40 : 41

~ 	public static void doBootstrap() {

> CHANGE  115 : 116  @  115 : 116

~ 			EaglercraftRandom random = this.enderman.getRNG();

> CHANGE  36 : 37  @  36 : 37

~ 			EaglercraftRandom random = this.enderman.getRNG();

> EOF
