
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  3 : 4  @  3 : 4

~ import net.lax1dude.eaglercraft.v1_8.EaglercraftUUID;

> CHANGE  14 : 15  @  14 : 15

~ 	private EaglercraftUUID id;

> CHANGE  4 : 5  @  4 : 5

~ 	public C18PacketSpectate(EaglercraftUUID id) {

> EOF
