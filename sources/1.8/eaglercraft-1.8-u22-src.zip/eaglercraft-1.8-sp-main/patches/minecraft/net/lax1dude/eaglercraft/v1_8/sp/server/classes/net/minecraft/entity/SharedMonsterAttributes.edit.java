
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  3 : 4  @  3 : 4

~ import net.lax1dude.eaglercraft.v1_8.EaglercraftUUID;

> CHANGE  5 : 9  @  5 : 9

~ import net.minecraft.nbt.NBTTagCompound;
~ import net.minecraft.nbt.NBTTagList;
~ import net.lax1dude.eaglercraft.v1_8.log4j.LogManager;
~ import net.lax1dude.eaglercraft.v1_8.log4j.Logger;

> CHANGE  40 : 41  @  40 : 41

~ 			for (AttributeModifier attributemodifier : (Collection<AttributeModifier>) collection) {

> CHANGE  57 : 59  @  57 : 58

~ 		EaglercraftUUID uuid = new EaglercraftUUID(parNBTTagCompound.getLong("UUIDMost"),
~ 				parNBTTagCompound.getLong("UUIDLeast"));

> EOF
