
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  21 : 22  @  21 : 22

~ import net.minecraft.nbt.NBTTagCompound;

> CHANGE  169 : 172  @  169 : 174

~ 			this.ignite();
~ 			itemstack.damageItem(1, entityplayer);
~ 			return true;

> CHANGE  6 : 7  @  6 : 7

~ 		{

> DELETE  6  @  6 : 7

> EOF
