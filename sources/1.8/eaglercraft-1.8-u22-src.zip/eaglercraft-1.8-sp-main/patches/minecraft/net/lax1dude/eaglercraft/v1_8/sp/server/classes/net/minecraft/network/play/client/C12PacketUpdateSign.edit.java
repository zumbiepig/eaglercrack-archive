
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  29 : 30  @  29 : 30

~ 		this.pos = parPacketBuffer.readBlockPos_server();

> CHANGE  11 : 12  @  11 : 12

~ 		parPacketBuffer.writeBlockPos_server(this.pos);

> EOF
