
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  10 : 11  @  10 : 11

~ import net.minecraft.crash.CrashReportCategory;

> CHANGE  3 : 5  @  3 : 5

~ import net.minecraft.nbt.NBTBase;
~ import net.minecraft.nbt.NBTTagCompound;

> CHANGE  66 : 67  @  66 : 67

~ 				} else {

> CHANGE  10 : 11  @  10 : 11

~ 			{

> CHANGE  38 : 40  @  38 : 40

~ 				} else if (this.fallTime > 100 && (blockpos1.getY() < 1 || blockpos1.getY() > 256)
~ 						|| this.fallTime > 600) {

> DELETE  7  @  7 : 8

> CHANGE  13 : 14  @  13 : 14

~ 				for (Entity entity : (ArrayList<Entity>) arraylist) {

> EOF
