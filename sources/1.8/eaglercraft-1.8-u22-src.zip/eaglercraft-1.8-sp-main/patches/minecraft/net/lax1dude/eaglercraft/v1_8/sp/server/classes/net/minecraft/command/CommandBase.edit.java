
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> INSERT  6 : 7  @  6

+ 

> CHANGE  5 : 6  @  5 : 6

~ import net.lax1dude.eaglercraft.v1_8.EaglercraftUUID;

> CHANGE  154 : 155  @  154 : 155

~ 						.getPlayerByUUID(EaglercraftUUID.fromString(username));

> CHANGE  31 : 32  @  31 : 32

~ 				EaglercraftUUID uuid = EaglercraftUUID.fromString(parString1);

> EOF
