
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  2 : 3  @  2 : 3

~ import net.lax1dude.eaglercraft.v1_8.EaglercraftRandom;

> CHANGE  11 : 12  @  11 : 12

~ import net.minecraft.nbt.NBTTagCompound;

> CHANGE  45 : 46  @  45 : 46

~ 		if (this.worldObj.getDifficulty() == EnumDifficulty.PEACEFUL) {

> CHANGE  203 : 204  @  203 : 204

~ 			EaglercraftRandom random = this.parentEntity.getRNG();

> EOF
