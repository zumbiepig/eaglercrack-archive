
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  49 : 50  @  49 : 50

~ 		this.windowTitle = parPacketBuffer.readChatComponent_server();

> CHANGE  10 : 11  @  10 : 11

~ 		parPacketBuffer.writeChatComponent_server(this.windowTitle);

> EOF
