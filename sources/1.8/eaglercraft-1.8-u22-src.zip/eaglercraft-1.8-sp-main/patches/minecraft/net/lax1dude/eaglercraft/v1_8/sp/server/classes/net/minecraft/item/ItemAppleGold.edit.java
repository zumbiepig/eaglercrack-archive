
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  35 : 36  @  35 : 38

~ 		entityplayer.addPotionEffect(new PotionEffect(Potion.absorption.id, 2400, 0));

> CHANGE  2 : 3  @  2 : 3

~ 			{

> EOF
