
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  13 : 14  @  13 : 14

~ import net.minecraft.nbt.NBTTagCompound;

> CHANGE  44 : 45  @  44 : 45

~ 		{

> CHANGE  40 : 41  @  40 : 41

~ 		if (this.isEntityAlive() && this.getBlocked()) {

> EOF
