
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  32 : 33  @  32 : 33

~ 		this.itemStack = parPacketBuffer.readItemStackFromBuffer_server();

> CHANGE  5 : 6  @  5 : 6

~ 		parPacketBuffer.writeItemStackToBuffer_server(this.itemStack);

> EOF
