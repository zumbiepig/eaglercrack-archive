
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  9 : 10  @  9 : 10

~ import net.minecraft.nbt.NBTTagCompound;

> CHANGE  67 : 68  @  67 : 68

~ 		if (itemstack != null && itemstack.getItem() == Items.lead) {

> CHANGE  11 : 12  @  11 : 12

~ 		if (!flag) {

> EOF
