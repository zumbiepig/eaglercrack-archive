
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  15 : 16  @  15 : 16

~ import net.minecraft.nbt.NBTTagCompound;

> CHANGE  114 : 115  @  114 : 115

~ 								for (BlockPos blockpos6 : (LinkedList<BlockPos>) linkedlist) {

> CHANGE  8 : 9  @  8 : 9

~ 								for (BlockPos blockpos7 : (LinkedList<BlockPos>) linkedlist) {

> CHANGE  10 : 11  @  10 : 11

~ 							for (CommandClone.StaticCloneData commandclone$staticclonedata : (List<CommandClone.StaticCloneData>) list) {

> CHANGE  12 : 13  @  12 : 13

~ 							for (CommandClone.StaticCloneData commandclone$staticclonedata1 : (ArrayList<CommandClone.StaticCloneData>) arraylist3) {

> CHANGE  6 : 7  @  6 : 7

~ 							for (CommandClone.StaticCloneData commandclone$staticclonedata2 : (ArrayList<CommandClone.StaticCloneData>) arraylist1) {

> CHANGE  17 : 18  @  17 : 18

~ 							for (CommandClone.StaticCloneData commandclone$staticclonedata3 : (List<CommandClone.StaticCloneData>) list) {

> CHANGE  6 : 7  @  6 : 7

~ 								for (NextTickListEntry nextticklistentry : (List<NextTickListEntry>) list1) {

> EOF
