
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  2 : 3  @  2 : 3

~ import net.lax1dude.eaglercraft.v1_8.mojang.authlib.GameProfile;

> CHANGE  1 : 2  @  1 : 2

~ import net.lax1dude.eaglercraft.v1_8.EaglercraftUUID;

> CHANGE  24 : 25  @  24 : 25

~ 		EaglercraftUUID uuid = EaglercraftUUID.fromString(s);

> CHANGE  4 : 5  @  4 : 5

~ 		EaglercraftUUID uuid = this.profile.getId();

> EOF
