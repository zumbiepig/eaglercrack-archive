
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  4 : 6  @  4 : 6

~ import net.lax1dude.eaglercraft.v1_8.mojang.authlib.GameProfile;
~ import net.lax1dude.eaglercraft.v1_8.mojang.authlib.Property;

> CHANGE  75 : 76  @  75 : 76

~ 					ichatcomponent = parPacketBuffer.readChatComponent_server();

> CHANGE  13 : 14  @  13 : 14

~ 					ichatcomponent = parPacketBuffer.readChatComponent_server();

> CHANGE  41 : 42  @  41 : 42

~ 					parPacketBuffer.writeChatComponent_server(s38packetplayerlistitem$addplayerdata.getDisplayName());

> CHANGE  16 : 17  @  16 : 17

~ 					parPacketBuffer.writeChatComponent_server(s38packetplayerlistitem$addplayerdata.getDisplayName());

> EOF
