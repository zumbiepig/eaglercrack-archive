
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  65 : 66  @  65 : 66

~ 		for (BlockState.StateImplementation blockstate$stateimplementation1 : (ArrayList<BlockState.StateImplementation>) arraylist) {

> CHANGE  97 : 98  @  97 : 98

~ 					for (Comparable comparable : (Collection<Comparable>) iproperty.getAllowedValues()) {

> EOF
