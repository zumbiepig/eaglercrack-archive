
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  3 : 4  @  3 : 4

~ import net.lax1dude.eaglercraft.v1_8.EaglercraftRandom;

> CHANGE  18 : 20  @  18 : 20

~ import net.minecraft.nbt.NBTTagCompound;
~ import net.minecraft.nbt.NBTUtil;

> CHANGE  110 : 111  @  110 : 111

~ 		{

> CHANGE  20 : 21  @  20 : 21

~ 	public Item getItemDropped(IBlockState var1, EaglercraftRandom var2, int var3) {

> CHANGE  5 : 6  @  5 : 6

~ 				&& this.getWitherBasePattern().match(worldIn, pos) != null;

> CHANGE  3 : 4  @  3 : 5

~ 		if (te.getSkullType() == 1 && pos.getY() >= 2 && worldIn.getDifficulty() != EnumDifficulty.PEACEFUL) {

> EOF
