
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  2 : 3  @  2 : 3

~ import net.lax1dude.eaglercraft.v1_8.EaglercraftRandom;

> CHANGE  87 : 88  @  87 : 88

~ 	public void randomTick(World worldIn, BlockPos pos, IBlockState state, EaglercraftRandom random) {

> CHANGE  2 : 4  @  2 : 4

~ 	public void updateTick(World worldIn, BlockPos pos, IBlockState state, EaglercraftRandom rand) {
~ 		{

> DELETE  4  @  4 : 5

> CHANGE  4 : 5  @  4 : 5

~ 		{

> DELETE  4  @  4 : 5

> EOF
