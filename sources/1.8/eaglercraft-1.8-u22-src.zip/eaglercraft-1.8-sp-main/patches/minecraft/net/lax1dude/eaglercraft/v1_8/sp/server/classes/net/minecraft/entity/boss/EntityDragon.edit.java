
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> DELETE  108  @  108 : 117

> CHANGE  36 : 37  @  36 : 52

~ 				{

> CHANGE  107 : 108  @  107 : 108

~ 				if (this.hurtTime == 0) {

> CHANGE  46 : 47  @  46 : 47

~ 				{

> DELETE  3  @  3 : 4

> CHANGE  7 : 8  @  7 : 8

~ 				{

> DELETE  3  @  3 : 4

> CHANGE  13 : 14  @  13 : 14

~ 			for (EntityEnderCrystal entityendercrystal1 : (List<EntityEnderCrystal>) list) {

> CHANGE  165 : 166  @  165 : 166

~ 		{

> CHANGE  18 : 19  @  18 : 19

~ 		if (this.deathTicks == 200) {

> EOF
