
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  22 : 24  @  22 : 24

~ import net.lax1dude.eaglercraft.v1_8.log4j.LogManager;
~ import net.lax1dude.eaglercraft.v1_8.log4j.Logger;

> CHANGE  68 : 70  @  68 : 70

~ 				if (!entityplayer.capabilities.isCreativeMode && iblockstate.getBlock() == Blocks.anvil
~ 						&& entityplayer.getRNG().nextFloat() < 0.12F) {

> CHANGE  10 : 11  @  10 : 11

~ 				} else {

> CHANGE  223 : 224  @  223 : 224

~ 		{

> DELETE  6  @  6 : 7

> EOF
