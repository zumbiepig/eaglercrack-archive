
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> INSERT  3 : 4  @  3

+ 

> CHANGE  19 : 20  @  19 : 20

~ import net.minecraft.nbt.NBTTagCompound;

> CHANGE  105 : 106  @  105 : 106

~ 		if (!this.isDead) {

> CHANGE  68 : 69  @  68 : 69

~ 		if (this.worldObj instanceof WorldServer) {

> CHANGE  37 : 38  @  37 : 55

~ 		{

> CHANGE  409 : 410  @  409 : 410

~ 		{

> EOF
