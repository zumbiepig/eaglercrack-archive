
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  3 : 4  @  3 : 4

~ import net.lax1dude.eaglercraft.v1_8.EaglercraftRandom;

> CHANGE  68 : 69  @  68 : 69

~ 		for (EntityAnimal entityanimal1 : (List<EntityAnimal>) list) {

> CHANGE  32 : 33  @  32 : 33

~ 			EaglercraftRandom random = this.theAnimal.getRNG();

> EOF
