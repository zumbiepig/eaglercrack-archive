
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  9 : 11  @  9 : 10

~ import net.lax1dude.eaglercraft.v1_8.EaglercraftRandom;
~ import net.lax1dude.eaglercraft.v1_8.HString;

> CHANGE  88 : 89  @  88 : 89

~ 		EaglercraftRandom random = new EaglercraftRandom();

> CHANGE  15 : 16  @  15 : 16

~ 					new Object[] { HString.format("%.2f", new Object[] { Double.valueOf(d4) }), Integer.valueOf(i) }));

> CHANGE  19 : 20  @  19 : 20

~ 			EaglercraftRandom parRandom, double parDouble2, double parDouble3, double parDouble4, double parDouble5,

> CHANGE  64 : 65  @  64 : 65

~ 							HString.format("%.2f", new Object[] { Double.valueOf(d0) }) });

> CHANGE  45 : 46  @  45 : 46

~ 	private CommandSpreadPlayers.Position[] func_110670_a(EaglercraftRandom parRandom, int parInt1, double parDouble1,

> CHANGE  98 : 99  @  98 : 99

~ 		public void func_111097_a(EaglercraftRandom parRandom, double parDouble1, double parDouble2, double parDouble3,

> EOF
