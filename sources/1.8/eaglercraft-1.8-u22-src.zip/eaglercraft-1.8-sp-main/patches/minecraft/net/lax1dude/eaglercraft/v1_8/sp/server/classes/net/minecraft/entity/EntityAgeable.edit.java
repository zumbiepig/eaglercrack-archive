
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  7 : 8  @  7 : 8

~ import net.minecraft.nbt.NBTTagCompound;

> CHANGE  27 : 28  @  27 : 28

~ 			{

> INSERT  20 : 21  @  20

+ 				return true;

> DELETE  1  @  1 : 3

> CHANGE  11 : 12  @  11 : 12

~ 		return this.growingAge;

> CHANGE  52 : 53  @  52 : 67

~ 		{

> DELETE  12  @  12 : 13

> EOF
