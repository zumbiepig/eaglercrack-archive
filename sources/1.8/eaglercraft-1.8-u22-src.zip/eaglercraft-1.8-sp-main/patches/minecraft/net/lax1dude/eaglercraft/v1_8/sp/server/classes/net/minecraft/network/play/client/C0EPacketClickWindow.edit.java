
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  46 : 47  @  46 : 47

~ 		this.clickedItem = parPacketBuffer.readItemStackFromBuffer_server();

> CHANGE  8 : 9  @  8 : 9

~ 		parPacketBuffer.writeItemStackToBuffer_server(this.clickedItem);

> EOF
