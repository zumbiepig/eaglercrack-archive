
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  2 : 3  @  2 : 3

~ import net.lax1dude.eaglercraft.v1_8.EaglercraftUUID;

> CHANGE  18 : 20  @  18 : 19

~ 	public static final EaglercraftUUID FLEEING_SPEED_MODIFIER_UUID = EaglercraftUUID
~ 			.fromString("E199AD21-BA8A-4C53-8D13-6182D5C69D3A");

> EOF
