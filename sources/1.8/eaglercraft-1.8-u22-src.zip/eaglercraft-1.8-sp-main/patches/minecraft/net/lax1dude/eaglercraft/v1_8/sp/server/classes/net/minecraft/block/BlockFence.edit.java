
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  153 : 154  @  153 : 154

~ 		return ItemLead.attachToFence(entityplayer, world, blockpos);

> EOF
