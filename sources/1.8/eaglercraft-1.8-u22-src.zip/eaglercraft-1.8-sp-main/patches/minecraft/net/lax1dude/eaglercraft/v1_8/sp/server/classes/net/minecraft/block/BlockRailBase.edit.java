
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> INSERT  3 : 4  @  3

+ 

> CHANGE  79 : 80  @  79 : 80

~ 		{

> DELETE  5  @  5 : 6

> CHANGE  3 : 4  @  3 : 4

~ 		{

> DELETE  27  @  27 : 28

> CHANGE  8 : 10  @  8 : 11

~ 		return (new BlockRailBase.Rail(worldIn, parBlockPos, parIBlockState))
~ 				.func_180364_a(worldIn.isBlockPowered(parBlockPos), parFlag).getBlockState();

> EOF
