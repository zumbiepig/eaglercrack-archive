
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  6 : 7  @  6 : 7

~ import net.minecraft.nbt.NBTTagCompound;

> INSERT  5 : 6  @  5

+ 

> CHANGE  76 : 77  @  76 : 77

~ 		if (this.tickCounter1++ == 100) {

> CHANGE  57 : 58  @  57 : 58

~ 			if (!this.isDead) {

> CHANGE  10 : 11  @  10 : 11

~ 		if (!this.isDead && d0 * d0 + d1 * d1 + d2 * d2 > 0.0D) {

> CHANGE  7 : 8  @  7 : 8

~ 		if (!this.isDead && d0 * d0 + d1 * d1 + d2 * d2 > 0.0D) {

> EOF
