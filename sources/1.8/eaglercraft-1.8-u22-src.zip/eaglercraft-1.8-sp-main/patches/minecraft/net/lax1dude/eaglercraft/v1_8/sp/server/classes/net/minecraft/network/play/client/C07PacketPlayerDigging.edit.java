
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  33 : 34  @  33 : 34

~ 		this.position = parPacketBuffer.readBlockPos_server();

> CHANGE  5 : 6  @  5 : 6

~ 		parPacketBuffer.writeBlockPos_server(this.position);

> EOF
