
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  2 : 3  @  2 : 3

~ import net.lax1dude.eaglercraft.v1_8.EaglercraftRandom;

> CHANGE  40 : 42  @  40 : 42

~ import net.minecraft.nbt.NBTTagCompound;
~ import net.minecraft.nbt.NBTTagList;

> CHANGE  295 : 296  @  295 : 296

~ 			if (this.buyingList == null || this.buyingList.size() > 0) {

> CHANGE  216 : 217  @  216 : 217

~ 		if (this.livingSoundTime > -this.getTalkInterval() + 20) {

> CHANGE  167 : 168  @  167 : 168

~ 		if (!this.isDead) {

> CHANGE  107 : 108  @  107 : 108

~ 		public void modifyMerchantRecipeList(MerchantRecipeList recipeList, EaglercraftRandom random) {

> CHANGE  10 : 11  @  10 : 11

~ 		void modifyMerchantRecipeList(MerchantRecipeList var1, EaglercraftRandom var2);

> CHANGE  16 : 17  @  16 : 17

~ 		public void modifyMerchantRecipeList(MerchantRecipeList merchantrecipelist, EaglercraftRandom random) {

> CHANGE  18 : 19  @  18 : 19

~ 		public void modifyMerchantRecipeList(MerchantRecipeList merchantrecipelist, EaglercraftRandom random) {

> CHANGE  23 : 24  @  23 : 24

~ 		public void modifyMerchantRecipeList(MerchantRecipeList merchantrecipelist, EaglercraftRandom random) {

> CHANGE  26 : 27  @  26 : 27

~ 		public void modifyMerchantRecipeList(MerchantRecipeList merchantrecipelist, EaglercraftRandom random) {

> CHANGE  24 : 25  @  24 : 25

~ 		public int getPrice(EaglercraftRandom rand) {

> EOF
