
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  3 : 4  @  3 : 4

~ import net.lax1dude.eaglercraft.v1_8.EaglercraftRandom;

> CHANGE  6 : 7  @  6 : 7

~ import net.minecraft.nbt.NBTTagCompound;

> CHANGE  45 : 46  @  45 : 46

~ 						{

> CHANGE  28 : 29  @  28 : 29

~ 	private void applyRandomRotations(EntityArmorStand armorStand, EaglercraftRandom rand) {

> EOF
