
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  2 : 3  @  2 : 3

~ import net.lax1dude.eaglercraft.v1_8.EaglercraftUUID;

> CHANGE  13 : 14  @  13 : 14

~ import net.minecraft.nbt.NBTTagCompound;

> CHANGE  13 : 14  @  13 : 14

~ 	private static final EaglercraftUUID ATTACK_SPEED_BOOST_MODIFIER_UUID = EaglercraftUUID

> CHANGE  5 : 6  @  5 : 6

~ 	private EaglercraftUUID angerTargetUUID;

> CHANGE  83 : 84  @  83 : 84

~ 			this.angerTargetUUID = EaglercraftUUID.fromString(s);

> EOF
