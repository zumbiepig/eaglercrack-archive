
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  51 : 52  @  51 : 55

~ 					world.playAuxSFX(2005, blockpos, 0);

> CHANGE  36 : 38  @  36 : 38

~ 			if (igrowable.canGrow(worldIn, target, iblockstate, false)) {
~ 				{

> EOF
