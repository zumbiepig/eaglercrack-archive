
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  37 : 38  @  37 : 38

~ import net.minecraft.nbt.NBTTagCompound;

> CHANGE  128 : 129  @  128 : 129

~ 		if (this.isWet && !this.isShaking && !this.hasPath() && this.onGround) {

> CHANGE  6 : 7  @  6 : 7

~ 		if (this.getAttackTarget() == null && this.isAngry()) {

> CHANGE  152 : 153  @  152 : 153

~ 			if (this.isOwner(entityplayer) && !this.isBreedingItem(itemstack)) {

> CHANGE  14 : 15  @  14 : 15

~ 			{

> EOF
