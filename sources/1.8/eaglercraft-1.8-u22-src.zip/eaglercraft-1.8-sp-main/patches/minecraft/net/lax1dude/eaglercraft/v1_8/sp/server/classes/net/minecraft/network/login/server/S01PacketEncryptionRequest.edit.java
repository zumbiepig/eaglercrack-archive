
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> DELETE  3  @  3 : 4

> DELETE  3  @  3 : 4

> DELETE  10  @  10 : 11

> DELETE  5  @  5 : 11

> CHANGE  2 : 3  @  2 : 3

~ 		parPacketBuffer.readByteArray();

> CHANGE  5 : 6  @  5 : 6

~ 		parPacketBuffer.writeByteArray(new byte[0]);

> DELETE  11  @  11 : 15

> EOF
