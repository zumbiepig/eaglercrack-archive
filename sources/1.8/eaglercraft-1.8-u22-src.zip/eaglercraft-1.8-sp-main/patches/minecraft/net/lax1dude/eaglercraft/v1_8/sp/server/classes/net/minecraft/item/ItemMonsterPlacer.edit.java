
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  60 : 61  @  60 : 63

~ 		if (!entityplayer.canPlayerEdit(blockpos.offset(enumfacing), enumfacing, itemstack)) {

> CHANGE  41 : 42  @  41 : 44

~ 		{

> EOF
