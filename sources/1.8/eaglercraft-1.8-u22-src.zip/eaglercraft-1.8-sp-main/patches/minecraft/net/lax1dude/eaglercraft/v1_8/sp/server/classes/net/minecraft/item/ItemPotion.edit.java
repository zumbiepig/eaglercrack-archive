
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> INSERT  10 : 12  @  10

+ import java.util.Set;
+ 

> CHANGE  9 : 11  @  9 : 11

~ import net.minecraft.nbt.NBTTagCompound;
~ import net.minecraft.nbt.NBTTagList;

> CHANGE  66 : 67  @  66 : 67

~ 		{

> CHANGE  2 : 3  @  2 : 3

~ 				for (PotionEffect potioneffect : (List<PotionEffect>) list) {

> CHANGE  32 : 33  @  32 : 35

~ 			world.spawnEntityInWorld(new EntityPotion(world, entityplayer, itemstack));

> CHANGE  24 : 25  @  24 : 25

~ 			for (PotionEffect potioneffect : (List<PotionEffect>) list) {

> CHANGE  37 : 38  @  37 : 38

~ 				for (PotionEffect potioneffect : (List<PotionEffect>) list1) {

> CHANGE  4 : 5  @  4 : 5

~ 						for (Entry entry : (Set<Entry<Object, Object>>) map.entrySet()) {

> CHANGE  33 : 34  @  33 : 34

~ 				for (Entry entry1 : (Set<Entry<Object, Object>>) hashmultimap.entries()) {

> EOF
