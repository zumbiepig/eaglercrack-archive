
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  9 : 10  @  9 : 10

~ import net.minecraft.nbt.NBTTagCompound;

> CHANGE  6 : 8  @  6 : 8

~ import net.lax1dude.eaglercraft.v1_8.log4j.LogManager;
~ import net.lax1dude.eaglercraft.v1_8.log4j.Logger;

> CHANGE  76 : 77  @  76 : 79

~ 				this.searchForOtherItemsNearby();

> CHANGE  21 : 22  @  21 : 22

~ 			if (this.age >= 6000) {

> CHANGE  138 : 139  @  138 : 139

~ 		{

> DELETE  42  @  42 : 43

> CHANGE  14 : 15  @  14 : 18

~ 		this.searchForOtherItemsNearby();

> EOF
