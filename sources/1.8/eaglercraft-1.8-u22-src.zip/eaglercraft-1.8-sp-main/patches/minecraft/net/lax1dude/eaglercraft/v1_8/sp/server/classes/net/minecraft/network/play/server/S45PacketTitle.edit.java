
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  45 : 46  @  45 : 46

~ 			this.message = parPacketBuffer.readChatComponent_server();

> CHANGE  13 : 14  @  13 : 14

~ 			parPacketBuffer.writeChatComponent_server(this.message);

> EOF
