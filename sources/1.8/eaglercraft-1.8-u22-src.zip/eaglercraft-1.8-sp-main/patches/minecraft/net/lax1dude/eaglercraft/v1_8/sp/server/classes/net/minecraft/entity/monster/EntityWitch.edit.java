
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  3 : 4  @  3 : 4

~ import net.lax1dude.eaglercraft.v1_8.EaglercraftUUID;

> CHANGE  34 : 36  @  34 : 35

~ 	private static final EaglercraftUUID MODIFIER_UUID = EaglercraftUUID
~ 			.fromString("5CD17E52-A79A-43D3-A529-90FDE04B181E");

> CHANGE  50 : 51  @  50 : 51

~ 		{

> CHANGE  8 : 9  @  8 : 9

~ 							for (PotionEffect potioneffect : (List<PotionEffect>) list) {

> EOF
