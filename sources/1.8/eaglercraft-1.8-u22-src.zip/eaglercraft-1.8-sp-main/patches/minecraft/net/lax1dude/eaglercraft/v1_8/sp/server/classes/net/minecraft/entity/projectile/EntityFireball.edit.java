
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  6 : 8  @  6 : 8

~ import net.minecraft.nbt.NBTTagCompound;
~ import net.minecraft.nbt.NBTTagList;

> CHANGE  76 : 77  @  76 : 77

~ 		if ((this.shootingEntity == null || !this.shootingEntity.isDead)

> EOF
