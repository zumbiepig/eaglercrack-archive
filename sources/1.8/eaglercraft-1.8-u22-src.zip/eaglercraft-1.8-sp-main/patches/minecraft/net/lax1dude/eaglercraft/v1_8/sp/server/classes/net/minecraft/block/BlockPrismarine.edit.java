
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  24 : 25  @  24 : 26

~ 	public static PropertyEnum<BlockPrismarine.EnumType> VARIANT;

> INSERT  10 : 14  @  10

+ 	public static void bootstrapStates() {
+ 		VARIANT = PropertyEnum.<BlockPrismarine.EnumType>create("variant", BlockPrismarine.EnumType.class);
+ 	}
+ 

> EOF
