
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  9 : 10  @  9 : 10

~ import net.lax1dude.eaglercraft.v1_8.EaglercraftUUID;

> CHANGE  17 : 18  @  17 : 18

~ 	private final Map<EaglercraftUUID, AttributeModifier> mapByUUID = Maps.newHashMap();

> CHANGE  44 : 45  @  44 : 45

~ 	public AttributeModifier getModifier(EaglercraftUUID uuid) {

> CHANGE  14 : 15  @  14 : 15

~ 				this.mapByName.put(attributemodifier.getName(), (Set<AttributeModifier>) object);

> CHANGE  35 : 36  @  35 : 36

~ 			for (AttributeModifier attributemodifier : (Collection<AttributeModifier>) Lists.newArrayList(collection)) {

> DELETE  2  @  2 : 3

> EOF
