
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  19 : 23  @  19 : 23

~ import net.minecraft.nbt.JsonToNBT;
~ import net.minecraft.nbt.NBTException;
~ import net.minecraft.nbt.NBTTagCompound;
~ import net.minecraft.nbt.NBTUtil;

> CHANGE  209 : 210  @  209 : 210

~ 			for (String s1 : (ArrayList<String>) arraylist1) {

> CHANGE  234 : 235  @  234 : 235

~ 			for (ScorePlayerTeam scoreplayerteam1 : (Collection<ScorePlayerTeam>) collection1) {

> CHANGE  115 : 116  @  115 : 116

~ 				for (String s : (ArrayList<String>) arraylist) {

> CHANGE  28 : 29  @  28 : 29

~ 			for (ScoreObjective scoreobjective : (Collection<ScoreObjective>) collection) {

> CHANGE  49 : 50  @  49 : 50

~ 			for (Score score : (Collection<Score>) map.values()) {

> CHANGE  339 : 340  @  339 : 340

~ 		for (ScoreObjective scoreobjective : (Collection<ScoreObjective>) collection) {

> CHANGE  12 : 13  @  12 : 13

~ 		for (ScoreObjective scoreobjective : (Collection<ScoreObjective>) collection) {

> EOF
