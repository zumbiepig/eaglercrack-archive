
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  21 : 22  @  21 : 22

~ import net.minecraft.nbt.NBTTagCompound;

> CHANGE  76 : 77  @  76 : 78

~ 		} else if (!this.getSaddled() || this.riddenByEntity != null && this.riddenByEntity != entityplayer) {

> CHANGE  42 : 43  @  42 : 43

~ 		if (!this.isDead) {

> EOF
