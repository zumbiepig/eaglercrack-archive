
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> CHANGE  15 : 16  @  15 : 16

~ import net.minecraft.nbt.NBTTagCompound;

> CHANGE  34 : 35  @  34 : 35

~ 		{

> CHANGE  10 : 11  @  10 : 11

~ 		{

> CHANGE  28 : 29  @  28 : 31

~ 		super.dropBlockAsItemWithChance(world, blockpos, iblockstate, f, 0);

> EOF
