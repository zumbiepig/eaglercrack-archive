
when you export the BuildTools source as a jar you must copy the "MANIFEST.MF" file in this directory into the "META-INF" directory inside the JAR!!

reasons: limitations in eclipse/intellij, lazyness
