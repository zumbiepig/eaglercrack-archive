#!/bin/sh
java -jar buildtools/BuildTools.jar merge_direct