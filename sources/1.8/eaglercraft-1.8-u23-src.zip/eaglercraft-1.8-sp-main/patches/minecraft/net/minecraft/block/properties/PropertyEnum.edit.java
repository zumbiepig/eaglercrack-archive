
# Eagler Context Redacted Diff
# Copyright (c) 2024 lax1dude. All rights reserved.

# Version: 1.0
# Author: lax1dude

> INSERT  2 : 5  @  2

+ import java.util.Collection;
+ import java.util.Map;
+ 

> CHANGE  6 : 7  @  6 : 9

~ 

> CHANGE  10 : 11  @  10 : 11

~ 		for (T oenum : allowedValues) {

> CHANGE  14 : 15  @  14 : 15

~ 	public String getName(Object oenum) {

> EOF
